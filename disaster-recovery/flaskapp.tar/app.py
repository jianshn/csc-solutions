from flask import Flask, render_template, request, json, redirect, url_for
import boto3
import mysql.connector
from logging import FileHandler, WARNING, INFO
import os

app = Flask(__name__)

file_handler = FileHandler('error.log')
file_handler.setLevel(WARNING)
file_handler.setLevel(INFO)

app.logger.addHandler(file_handler)

# MySQL configurations
stream = os.popen('curl http://169.254.169.254/latest/meta-data/placement/region')
region = stream.read()
client = boto3.client('secretsmanager', region_name=region)
secret = json.loads(client.get_secret_value(SecretId='mysecret')['SecretString'])
host = secret['host']
username = secret['username']
password = secret['password']
cnx = mysql.connector.connect(user=username, password=password, host=host, database='BucketList')


@app.route("/")
def main():
    return render_template('index.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route("/api/signup",methods=['GET', 'POST'])
def signUp():
    # read the posted values from the UI
    _name = request.form['inputName']
    _email = request.form['inputEmail']
    _password = request.form['inputPassword']

    # validate the received values
    if _name and _email and _password:
        print(json.dumps({'html':'<span>All fields good !!</span>'}))

        if request.method == 'POST':
            cnx._open_connection()
            cursor = cnx.cursor()
            cursor.callproc('sp_createUser',(_name,_email,_password))
            data=''

            for result in cursor.stored_results():
                data = result.fetchall()

            if len(data) == 0:
                cnx.commit()
                message = json.dumps({'message':'User created successfully !'})
            else:
                message =  json.dumps({'error':str(data[0])})

            cursor.close()
            cnx.close()

            file_html = open("templates/response.html", "w")
            # Adding the input data to the HTML file
            tmp = "<!-- response.html --> \n {}".format(message)
            file_html.write(tmp)
            # Saving the data into the HTML file
            file_html.close()
            print('just before redirect')
            return redirect(url_for("response"), code=302)
        else:
            print('redner signup page again')

    else:
        print(json.dumps({'html':'<span>Enter the required fields</span>'}))

@app.route("/response")
def response():
    return render_template('response.html')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True)
