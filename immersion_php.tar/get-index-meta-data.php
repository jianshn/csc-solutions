<?php

// Set options for retrieving the token
$options = array(
    'http' => array(
        'method' => 'PUT',
        'header' => "X-aws-ec2-metadata-token-ttl-seconds: 21600"
    )
);

// Context creation
$context = stream_context_create($options);

// Fetch token
$token = file_get_contents("http://169.254.169.254/latest/api/token", false, $context);

// Trim token
$token = trim($token);

// Set options for retrieving metadata using token
$options = array(
    'http' => array(
        'header' => "X-aws-ec2-metadata-token: $token"
    )
);

// Context creation
$context = stream_context_create($options);

// Additional script
echo "<table>";
echo "<tr><th>Meta-Data</th><th>Value</th></tr>";

#The URL root is the AWS meta data service URL where metadata
# requests regarding the running instance can be made
$urlRoot="http://169.254.169.254/latest/meta-data/";

# Get the instance ID from meta-data and print to the screen
echo "<tr><td>InstanceId</td><td><i>" . file_get_contents($urlRoot . 'instance-id', false, $context) . "</i></td><tr>";

# Availability Zone
echo "<tr><td>Availability Zone</td><td><i>" . file_get_contents($urlRoot . 'placement/availability-zone', false, $context) . "</i></td><tr>";

echo "</table>";

?>
